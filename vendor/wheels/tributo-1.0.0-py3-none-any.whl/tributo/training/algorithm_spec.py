"""Algorithm specification with ML metadata.

Extends the legacy ``TrainerSpec`` with three semantic groups of fields:

* **execution_kind** — what lifecycle shape the algorithm follows
  (``TRAIN`` / ``ESTIMATE`` / ``TRANSFORM``).
* **capabilities** — what infrastructure features the algorithm supports
  (``TUNABLE`` / ``EXPORTABLE`` / ``DISTRIBUTED`` / ``INCREMENTAL``).
* **problem_types** — what ML problems it *solves* (classification, ranking, etc.).
* **data_contract** — what data shape it *expects and produces*.

The canonical implementation adds:

* **taxonomy** — ``AlgorithmStatus``, ``ProblemFamily``, ``DataLoadingMode``.
* **lifecycle** — ``status``, ``deprecated_since``, ``replacement`` with
  ``__post_init__`` invariants.
* **deep immutability** — all container fields are recursively frozen via
  ``deep_freeze`` so that a ``Catalog`` snapshot cannot be mutated back
  into the ``Registry``.

Phase 4 (algorithm extensibility) adds:

* **execution kind** — ``ExecutionKind`` orthogonal to data modality and
  problem type; determines lifecycle skeleton.
* **capability tags** — Composable ``Capability`` flags that let
  ``TuneRunner``, ``BundleExportService``, and other infrastructure
  components gate their behaviour without hard-coding trainer subclasses.

Backward-compatible: ``TrainerSpec`` is a pure type alias in ``base.py``.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

from tributo._common.immutable import deep_freeze
from tributo.exceptions import JobConfigurationError
from tributo.util.annotations import PublicAPI

if TYPE_CHECKING:
    from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Problem type taxonomy
# ---------------------------------------------------------------------------


@PublicAPI(stability="beta")
class ProblemType(str, Enum):
    """ML problem types an algorithm can address.

    These describe the *semantic* task, orthogonal to lifecycle capabilities
    (train / finetune / predict) declared in ``supported_tasks``.
    """

    BINARY_CLASSIFICATION = "binary_classification"
    MULTI_CLASS_CLASSIFICATION = "multi_class_classification"
    MULTI_LABEL_CLASSIFICATION = "multi_label_classification"
    REGRESSION = "regression"
    RANKING = "ranking"
    ANOMALY_DETECTION = "anomaly_detection"
    CLUSTERING = "clustering"
    PU_LEARNING = "pu_learning"
    # -- graph learning --------------------------------------------------------
    NODE_CLASSIFICATION = "node_classification"
    LINK_PREDICTION = "link_prediction"
    GRAPH_CLASSIFICATION = "graph_classification"
    # -- causal inference ------------------------------------------------------
    CAUSAL_EFFECT_ESTIMATION = "causal_effect_estimation"
    # -- user analytics --------------------------------------------------------
    USER_CHURN_PREDICTION = "user_churn_prediction"
    USER_PROFILING = "user_profiling"


# ---------------------------------------------------------------------------
# Problem family (aggregation over ProblemType)
# ---------------------------------------------------------------------------


@PublicAPI(stability="beta")
class ProblemFamily(str, Enum):
    """Logical groupings of ``ProblemType`` values for CLI / filtering.

    ``classification`` expands to BINARY + MULTI_CLASS + MULTI_LABEL.
    """

    CLASSIFICATION = "classification"
    REGRESSION = "regression"
    RANKING = "ranking"
    CLUSTERING = "clustering"
    ANOMALY_DETECTION = "anomaly_detection"
    PU_LEARNING = "pu_learning"


PROBLEM_FAMILY_MAP: dict[ProblemFamily, tuple[ProblemType, ...]] = {
    ProblemFamily.CLASSIFICATION: (
        ProblemType.BINARY_CLASSIFICATION,
        ProblemType.MULTI_CLASS_CLASSIFICATION,
        ProblemType.MULTI_LABEL_CLASSIFICATION,
    ),
    ProblemFamily.REGRESSION: (ProblemType.REGRESSION,),
    ProblemFamily.RANKING: (ProblemType.RANKING,),
    ProblemFamily.CLUSTERING: (ProblemType.CLUSTERING,),
    ProblemFamily.ANOMALY_DETECTION: (ProblemType.ANOMALY_DETECTION,),
    ProblemFamily.PU_LEARNING: (ProblemType.PU_LEARNING,),
}


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


@PublicAPI(stability="beta")
class AlgorithmStatus(str, Enum):
    """Algorithm lifecycle stage.

    ``READY`` — fully supported, appears in ``list()`` and recommendations.
    ``DEPRECATED`` — hidden by default in ``list()``, triggers
    ``FutureWarning`` on ``get_spec()``.
    """

    READY = "ready"
    DEPRECATED = "deprecated"


# ---------------------------------------------------------------------------
# Data loading ownership
# ---------------------------------------------------------------------------


@PublicAPI(stability="beta")
class DataLoadingMode(str, Enum):
    """Who is responsible for loading data.

    ``LEGACY_DRIVER`` — old plugin contract; flat ``data`` dict is
    normalised by the legacy adapter and the Runner loads data.

    ``CANONICAL_DRIVER`` — Runner loads data from ``data.source``
    before constructing the trainer (XGBoost, DNN).

    ``CANONICAL_TRAINER`` — the trainer itself loads data inside the
    worker from the normalised ``data.source`` (PU).
    """

    LEGACY_DRIVER = "legacy_driver"
    CANONICAL_DRIVER = "canonical_driver"
    CANONICAL_TRAINER = "canonical_trainer"


# ---------------------------------------------------------------------------
# Execution kind (lifecycle skeleton)
# ---------------------------------------------------------------------------


@PublicAPI(stability="beta")
class ExecutionKind(str, Enum):
    """Execution mode — describes the algorithm's lifecycle shape.

    Orthogonal to ``ProblemType`` (semantic task) and ``data_modality``
    (data shape). Infrastructure components gate their behaviour on
    ``execution_kind`` without hard-coding trainer subclasses.

    ``TRAIN`` — ``setup → training_loop → export`` (existing three algorithms).
    ``ESTIMATE`` — ``identify → estimate → refute`` (causal inference).
    ``TRANSFORM`` — stateless transformation (feature engineering steps).
    """

    TRAIN = "train"
    ESTIMATE = "estimate"
    TRANSFORM = "transform"


# ---------------------------------------------------------------------------
# Capability tags (composable, non-exclusive)
# ---------------------------------------------------------------------------


@PublicAPI(stability="beta")
class Capability(str, Enum):
    """Algorithm capability tags — composable flags, not mutually exclusive.

    Each tag gates a specific infrastructure feature:
    ``TUNABLE`` — supports ``TuneRunner`` hyperparameter search.
    ``EXPORTABLE`` — produces a serialisable artifact.
    ``DISTRIBUTED`` — supports multi-worker distributed execution.
    ``INCREMENTAL`` — supports incremental / online updates.
    """

    TUNABLE = "tunable"
    EXPORTABLE = "exportable"
    DISTRIBUTED = "distributed"
    INCREMENTAL = "incremental"


# ---------------------------------------------------------------------------
# Data contract
# ---------------------------------------------------------------------------


@PublicAPI(stability="beta")
@dataclass(frozen=True)
class DataContract:
    """Describes the expected input / output data shape for an algorithm.

    Attributes:
        columns: Expected column names and their types.
        sparse: Sparse feature column name patterns.
        dense: Dense feature column name patterns.
        min_rows: Minimum recommended row count (``None`` = no constraint).
    """

    columns: Mapping[str, str] = field(default_factory=dict)
    sparse: tuple[str, ...] = ()
    dense: tuple[str, ...] = ()
    min_rows: int | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "columns", deep_freeze(self.columns))
        object.__setattr__(self, "sparse", tuple(self.sparse))
        object.__setattr__(self, "dense", tuple(self.dense))


# ---------------------------------------------------------------------------
# Resource hints
# ---------------------------------------------------------------------------


@PublicAPI(stability="beta")
@dataclass(frozen=True)
class ResourceHints:
    """Runtime resource recommendations for an algorithm.

    These are *hints*, not hard requirements — the scheduler may override them.

    Attributes:
        gpu_required: Whether a GPU is necessary (vs. nice-to-have).
        min_memory_gb: Minimum recommended RAM in GiB.
        min_cpus: Minimum recommended CPU cores.
    """

    gpu_required: bool = False
    min_memory_gb: int = 2
    min_cpus: int = 1


# ---------------------------------------------------------------------------
# AlgorithmSpec
# ---------------------------------------------------------------------------


@PublicAPI(stability="beta")
@dataclass(frozen=True)
class AlgorithmSpec:
    """Complete specification of a trainable algorithm.

    Field groups are named after their semantic domain to prevent confusion
    between ``supported_tasks`` (capabilities — "can it train?") and
    ``problem_types`` (ML semantics — "is it a classifier?").

    Attributes:
        name: Short algorithm name (e.g. ``"xgboost"``).
        trainer_cls: Legacy ``BaseTrainer`` subclass. New portable
            registrations set this explicitly to ``None``.
        default_config: Default configuration dict (deep-frozen at init).
        supported_tasks: Lifecycle actions the algorithm supports.
        version: Algorithm implementation version.
        resource_hints: Runtime resource recommendations.
        extras_group: ``pip install`` extra needed (``"training"``, ``"identity"``).
        problem_types: ML problem types this algorithm can address.
        data_modality: Input data modalities (``["tabular"]``, ``["graph"]``).
        tags: Free-form classification tags.
        input_schema: Expected input feature description.
        output_schema: Expected output format description.
        config_model: Pydantic model for config validation.
        execution_kind: Lifecycle skeleton (``TRAIN`` / ``ESTIMATE`` / ``TRANSFORM``).
        capabilities: Composable infrastructure feature flags
            (``TUNABLE`` / ``EXPORTABLE`` / ``DISTRIBUTED`` / ``INCREMENTAL``);
            must be declared explicitly — no capabilities are assumed.
        status: Lifecycle stage.
        deprecated_since: Version when deprecated (e.g. ``"0.4.0"``).
        replacement: Name of the replacement algorithm.
        data_loading: Who owns data loading.
        operations: Portable operation names. When set, this is projected to
            the legacy ``supported_tasks`` read view during migration.
        learning_paradigm: Supervision semantics such as ``supervised`` or
            ``positive_unlabeled``.
        model_family: Framework-neutral model family.
        data_modalities: Portable input modalities. When set, this is
            projected to the legacy ``data_modality`` read view.
        lifecycle_kind: Portable lifecycle identity.
        allowed_execution_modes: Execution modes permitted for registered
            implementations.
        config_contract_ref: Versioned configuration contract identifier.
        input_contract_ref: Versioned input contract identifier.
        output_contract_ref: Versioned output contract identifier.
    """

    # -- required fields -------------------------------------------------------
    name: str
    trainer_cls: type | None

    # -- legacy TrainerSpec fields ---------------------------------------------
    default_config: Mapping[str, Any] = field(default_factory=dict)
    supported_tasks: tuple[str, ...] = ("train",)

    # -- version & provenance --------------------------------------------------
    version: str = "0.1.0"

    # -- capabilities ----------------------------------------------------------
    resource_hints: ResourceHints = field(default_factory=ResourceHints)
    extras_group: str | None = None

    # -- problem types ---------------------------------------------------------
    problem_types: tuple[ProblemType, ...] = ()
    data_modality: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()

    # -- data contract ---------------------------------------------------------
    input_schema: DataContract | None = None
    output_schema: DataContract | None = None
    config_model: type[BaseModel] | None = None

    # -- execution kind & capabilities (Phase 4: algorithm extensibility) ------
    execution_kind: ExecutionKind = ExecutionKind.TRAIN
    # No default capabilities: every algorithm must declare the
    # infrastructure features it actually supports, otherwise capability
    # gates (e.g. TuneRunner's TUNABLE check) can never reject anything.
    capabilities: tuple[Capability, ...] = ()

    # -- lifecycle -------------------------------------------------------------
    status: AlgorithmStatus = AlgorithmStatus.READY
    deprecated_since: str | None = None
    replacement: str | None = None

    # -- data loading ----------------------------------------------------------
    data_loading: DataLoadingMode = DataLoadingMode.LEGACY_DRIVER

    # -- portable execution target fields ------------------------------------
    # These fields are framework-neutral strings so that Driver-side catalog
    # and planning code never imports a user implementation or framework.
    operations: tuple[str, ...] = ()
    learning_paradigm: str | None = None
    model_family: str | None = None
    data_modalities: tuple[str, ...] = ()
    lifecycle_kind: str | None = None
    allowed_execution_modes: tuple[str, ...] = ()
    config_contract_ref: str | None = None
    input_contract_ref: str | None = None
    output_contract_ref: str | None = None

    def __post_init__(self) -> None:
        # Runtime plugin entry points are not type-checked. Normalize valid
        # string enum values here so every Registry consumer sees one canonical
        # representation, and reject invalid declarations before registration.
        try:
            object.__setattr__(
                self,
                "problem_types",
                tuple(ProblemType(item) for item in self.problem_types),
            )
            object.__setattr__(
                self, "execution_kind", ExecutionKind(self.execution_kind)
            )
            object.__setattr__(
                self,
                "capabilities",
                tuple(Capability(item) for item in self.capabilities),
            )
            object.__setattr__(self, "status", AlgorithmStatus(self.status))
            object.__setattr__(
                self,
                "data_loading",
                DataLoadingMode(self.data_loading),
            )
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"Algorithm '{self.name}' contains an invalid enum declaration: {exc}"
            ) from exc

        # ── deep-freeze mutable containers ──
        object.__setattr__(self, "default_config", deep_freeze(self.default_config))
        object.__setattr__(self, "supported_tasks", tuple(self.supported_tasks))
        object.__setattr__(self, "data_modality", tuple(self.data_modality))
        object.__setattr__(self, "tags", tuple(self.tags))
        object.__setattr__(self, "operations", tuple(self.operations))
        object.__setattr__(self, "data_modalities", tuple(self.data_modalities))
        object.__setattr__(
            self, "allowed_execution_modes", tuple(self.allowed_execution_modes)
        )

        if self.operations:
            if (
                self.supported_tasks != ("train",)
                and self.supported_tasks != self.operations
            ):
                raise ValueError(
                    f"Algorithm '{self.name}': operations and supported_tasks conflict"
                )
            object.__setattr__(self, "supported_tasks", self.operations)
        if self.data_modalities:
            if self.data_modality and self.data_modality != self.data_modalities:
                raise ValueError(
                    f"Algorithm '{self.name}': data_modalities and data_modality conflict"
                )
            object.__setattr__(self, "data_modality", self.data_modalities)

        for field_name, values in (
            ("operations", self.operations),
            ("data_modalities", self.data_modalities),
            ("allowed_execution_modes", self.allowed_execution_modes),
        ):
            if any(not isinstance(value, str) or not value for value in values):
                raise ValueError(
                    f"Algorithm '{self.name}': {field_name} requires non-empty strings"
                )
        for field_name in (
            "learning_paradigm",
            "model_family",
            "lifecycle_kind",
            "config_contract_ref",
            "input_contract_ref",
            "output_contract_ref",
        ):
            value = getattr(self, field_name)
            if value is not None and (not isinstance(value, str) or not value):
                raise ValueError(
                    f"Algorithm '{self.name}': {field_name} must be a non-empty string"
                )

        # ── lifecycle invariants ──
        if self.status == AlgorithmStatus.DEPRECATED:
            if self.deprecated_since is None:
                raise ValueError(
                    f"Algorithm '{self.name}': status=DEPRECATED requires "
                    f"deprecated_since (e.g. '0.4.0')"
                )
            if self.replacement is None:
                raise ValueError(
                    f"Algorithm '{self.name}': status=DEPRECATED requires "
                    f"replacement (name of the replacement algorithm)"
                )
            if self.replacement == self.name:
                raise ValueError(
                    f"Algorithm '{self.name}': replacement must not be self"
                )
        else:  # READY
            if self.deprecated_since is not None:
                raise ValueError(
                    f"Algorithm '{self.name}': deprecated_since must be None "
                    f"when status={self.status.value}"
                )
            if self.replacement is not None:
                raise ValueError(
                    f"Algorithm '{self.name}': replacement must be None "
                    f"when status={self.status.value}"
                )


def require_legacy_trainer_cls(
    spec: AlgorithmSpec,
    *,
    consumer: str,
) -> type:
    """Return a legacy Trainer class or raise an accurate compatibility error."""
    trainer_cls = spec.trainer_cls
    if trainer_cls is not None:
        return trainer_cls
    if spec.operations:
        reason = "uses the portable execution path"
    else:
        reason = "is missing the required trainer_cls declaration"
    raise JobConfigurationError(
        f"Algorithm {spec.name!r} {reason} and cannot be constructed by "
        f"the legacy {consumer}"
    )
