"""Minimal KnoVa-to-Tributo mapping for distributed XGBoost training."""

from __future__ import annotations

import logging
import math
import os
import posixpath
import re
from collections.abc import Callable, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from traceback import format_list, walk_tb
from typing import Any, Literal, NoReturn, cast
from urllib.parse import urlsplit

from tributo.algorithms import (
    AlgorithmOperation,
    AlgorithmRequest,
    ExecutionProfile,
    ExecutionRequest,
    InputBinding,
    WorkerResources,
)
from tributo.algorithms.api import AlgorithmRunResult
from tributo.algorithms.spi import InputExecutionContext, InputResolutionContext
from tributo.data import (
    ColumnRename,
    FilterComparison,
    FilterEq,
    FilterNotEq,
    IngestionRequest,
    Limit,
    ProviderSourceConfig,
    RenameColumns,
    SelectColumns,
    TransformPipeline,
)
from tributo.exceptions import DataQueryError, DataSourceError
from tributo.exporting import BundleRef, load_bundle
from tributo.integrations.algorithm_inputs import (
    INGESTION_RESOLVER_ID,
    IngestionInputInvocation,
)
from tributo_algorithms_boosting import run_xgboost_training

from tributo_broker_redis.profiles.aimodel_v2.protocol import TrainingExecutionRequest
from tributo_broker_redis.profiles.aimodel_v2.validation import (
    ProtocolValidationError,
    validate_training_payload,
)

_INPUT_REFERENCE = "knova.training.input"
_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_ENV_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_SHARED_STORAGE_TYPES = frozenset({"nfs", "nas", "shared_fs"})
_CONTROL_HYPER_PARAMETERS = frozenset(
    {
        "early_stopping_rounds",
        "eval_metric",
        "n_estimators",
        "num_rounds",
        "objective",
        "num_class",
    }
)
_SENSITIVE_PROPERTY_TOKENS = frozenset(
    {"access", "credential", "key", "password", "secret", "token"}
)
logger = logging.getLogger(__name__)
_KNOWN_DATA_FAILURES = {
    "training dataset is empty": "Training input is empty after filtering",
    "Couldn't create non-empty splits with the given proportions.": (
        "Training input is too small for the configured train/validation/test split"
    ),
}


def _log_training_failure(message: str, job_id: str, error: Exception) -> None:
    """Keep frame locations without logging credentials from exception details."""
    # Do not pass exc_info: handlers may render exception messages, causes,
    # notes or source lines containing credentials. Frame locations and the
    # exception type still identify the failing call in Ray Job logs.
    frames = [
        (frame.f_code.co_filename, lineno, frame.f_code.co_name, "")
        for frame, lineno in walk_tb(error.__traceback__)
    ]
    logger.error(
        "%s: operation_id=%s error_type=%s\n"
        "Traceback (most recent call last):\n%s"
        "%s: exception details omitted",
        message,
        job_id,
        type(error).__name__,
        "".join(format_list(frames)),
        type(error).__name__,
    )


class _TrainingConfigurationError(ValueError):
    """Credential-safe request mapping failure."""

    code = "INVALID_PAYLOAD"
    phase = "QUEUED"


class _TrainingExecutionError(RuntimeError):
    """Credential-safe execution failure."""

    code = "TRAINING_FAILED"
    phase = "TRAINING"


def _classify_training_failure(
    error: Exception, reporter: Any, *, publishing: bool = False
) -> tuple[str, str]:
    """Classify by execution context without inspecting sensitive exception text."""
    phase = getattr(reporter, "_current_phase", "LOADING_DATA")
    phase = {
        "PREPARING": "LOADING_DATA",
        "EXECUTING": "TRAINING",
        "MATERIALIZING": "EVALUATING",
        "PUBLISHING": "EVALUATING",
    }.get(phase, phase)
    causes: list[Exception] = []
    cause: BaseException | None = error
    while isinstance(cause, Exception) and all(cause is not item for item in causes):
        causes.append(cause)
        cause = cause.__cause__
    frames = tuple(frame for item in causes for frame in walk_tb(item.__traceback__))
    exporting = publishing or any(
        (
            frame.f_globals.get("__name__") == "tributo_algorithms_boosting.training"
            and frame.f_code.co_name == "_export_bundle"
        )
        or (
            frame.f_globals.get("__name__") == __name__
            and frame.f_code.co_name in {"_artifact_manifest", "_artifact_storage"}
        )
        for frame, _ in frames
    )
    if exporting:
        return "MODEL_EXPORT_FAILED", "EVALUATING"
    if any(
        isinstance(item, (DataSourceError, DataQueryError)) for item in causes
    ) or any(
        frame.f_globals.get("__name__")
        in {
            "tributo.data.ingestion",
            "ray_clickhouse.datasource",
            "ray_clickhouse._discovery",
            "ray_clickhouse._planning",
        }
        for frame, _ in frames
    ):
        return "DATA_QUERY_FAILED", "LOADING_DATA"
    if phase in {"LOADING_DATA", "DATA_SPLITTING"}:
        code = (
            "DATA_SOURCE_UNREACHABLE"
            if isinstance(error, (ConnectionError, TimeoutError))
            else "DATA_QUERY_FAILED"
        )
        return code, phase
    return {
        "FEATURE_ENGINEERING": "FEATURE_ENGINEERING_FAILED",
        "EVALUATING": "EVALUATION_FAILED",
    }.get(phase, "TRAINING_FAILED"), phase


def _execution_error(message: str, code: str, phase: str) -> _TrainingExecutionError:
    error = _TrainingExecutionError(message)
    error.code = code
    error.phase = phase
    return error


@dataclass(frozen=True)
class _RayClassAmountSampler:
    """Apply KnoVa's materialized class quotas with native Ray Data APIs."""

    label_name: str
    limits: tuple[tuple[object, int], ...]

    def __call__(self, dataset: Any) -> Any:
        from ray.data.expressions import col

        # Materialize the canonical ClickHouse read once so each class branch
        # reuses the same blocks instead of issuing one full table scan per class.
        source = dataset.materialize()
        branches = [
            source.filter(expr=col(self.label_name) == value).limit(count)
            for value, count in self.limits
        ]
        return branches[0].union(*branches[1:])


class _TrainingDataError(_TrainingExecutionError):
    code = "DATA_QUERY_FAILED"
    phase = "LOADING_DATA"


class _EmptyTrainingDataError(_TrainingDataError):
    code = "EMPTY_DATASET"


def _first_entity_row(batch: Any) -> Any:
    return batch.iloc[:1]


@dataclass
class _RayInputValidation:
    """Validate loaded result columns and entity grain using native Ray Data."""

    payload: Mapping[str, Any]
    transform: Callable[[Any], Any] | None
    reporter: Any = None

    def _warning(self, message: str) -> None:
        logger.warning(message)
        if self.reporter is not None:
            self.reporter.publish(
                "LOG", {"level": "warning", "message": message}, phase="LOADING_DATA"
            )

    def __call__(self, dataset: Any) -> Any:
        if callable(getattr(self.reporter, "check_control", None)):
            self.reporter.check_control()
        expected = set(_column_mapping(self.payload).values())
        schema = dataset.schema()
        if schema is None and dataset.count() == 0:
            raise _EmptyTrainingDataError("Training input is empty after filtering")
        missing = expected.difference(schema.names if schema is not None else ())
        if missing:
            raise _TrainingDataError(
                "Training query result is missing declared result_column: "
                + ", ".join(sorted(missing))
            )
        entity = self.payload["data_query"].get("entity_key")
        if entity is not None:
            source = dataset.materialize()
            # Native groupby works across partitions; per-batch duplicates would
            # miss duplicate entities arriving in different ClickHouse blocks.
            distinct = (
                source.groupby(entity["result_column"])
                .map_groups(_first_entity_row, batch_format="pandas")
                .materialize()
            )
            if distinct.count() != source.count():
                self._warning(
                    "Duplicate entity keys in training query; "
                    "keeping one row per entity"
                )
            dataset = distinct
        if self.transform is not None:
            # Class quotas are applied before label encoding by _RayLabelEncoder.
            dataset = self.transform(dataset)
        balance = self.payload.get("data_sampling", {}).get("class_balance")
        if (
            balance
            and balance.get("strategy") in {"UNDERSAMPLE", "CUSTOM_AMOUNT"}
            and balance.get("class_amounts")
        ):
            target = self.payload["target"]
            mapping = target.get("label_mapping") or {}
            from ray.data.expressions import col

            dataset = dataset.materialize()
            for raw_label, expected_count in balance["class_amounts"].items():
                label = mapping.get(raw_label, raw_label)
                if raw_label not in mapping:
                    label = _query_scalar(raw_label, target["origin"]["column_type"])
                actual = dataset.filter(
                    expr=col(target["result_column"]) == label
                ).count()
                if abs(actual - expected_count) / expected_count > 0.05:
                    self._warning(
                        "Training class sample count differs from class_amounts "
                        "by more than 5%"
                    )
        names, label = _columns(self.payload)
        return dataset.select_columns([*names, label])


def _encode_target_batch(
    batch: Any, *, label_name: str, label_mapping: Mapping[str, int], num_class: int
) -> Any:
    """Encode raw string labels; preserve already encoded numeric targets."""
    import numpy as np
    import pandas as pd

    target = batch[label_name]
    if target.isna().any():
        _invalid("target contains null classification labels")
    numeric_values = pd.api.types.infer_dtype(target.to_numpy(), skipna=False) in {
        "integer",
        "floating",
        "mixed-integer-float",
        "decimal",
        "boolean",
    }
    if pd.api.types.is_numeric_dtype(target.dtype) or numeric_values:
        encoded = pd.to_numeric(target, errors="coerce")
    else:
        encoded = target.map(label_mapping)
    values = encoded.to_numpy(dtype=float)
    if (
        not np.isfinite(values).all()
        or (values != np.floor(values)).any()
        or (values < 0).any()
        or (values >= num_class).any()
    ):
        _invalid("target contains unknown or invalid classification labels")
    result = batch.copy()
    result[label_name] = values.astype(np.int64)
    return result


@dataclass(frozen=True)
class _RayLabelEncoder:
    """Use native Ray batch mapping after any raw-label class sampling."""

    label_name: str
    label_mapping: Mapping[str, int]
    num_class: int
    sampler: _RayClassAmountSampler | None = None

    def __call__(self, dataset: Any) -> Any:
        if self.sampler is not None:
            dataset = self.sampler(dataset)
        return dataset.map_batches(
            _encode_target_batch,
            batch_format="pandas",
            fn_kwargs={
                "label_name": self.label_name,
                "label_mapping": self.label_mapping,
                "num_class": self.num_class,
            },
        )


def _target_encoder(
    target: Mapping[str, Any],
    label_name: str,
    model: Mapping[str, Any],
    sampler: _RayClassAmountSampler | None,
) -> Callable[[Any], Any] | None:
    if target.get("task_type", "").upper() == "REGRESSION":
        return sampler
    num_class = model.get("num_class", 2)
    mapping = target.get("label_mapping")
    if mapping is None:
        mapping = {}
    mapping = _mapping(mapping, "target.label_mapping")
    if mapping and (
        any(
            not isinstance(value, int) or isinstance(value, bool)
            for value in mapping.values()
        )
        or len(mapping) != num_class
        or set(mapping.values()) != set(range(num_class))
    ):
        _invalid("target.label_mapping must uniquely encode every class from zero")
    return _RayLabelEncoder(label_name, dict(mapping), num_class, sampler)


def _invalid(message: str) -> NoReturn:
    raise _TrainingConfigurationError(message)


def _mapping(value: object, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        _invalid(f"{field} must be an object")
    return value


def _text(value: object, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        _invalid(f"{field} must be a non-empty string")
    return value.strip()


def _native_table_name(value: str, database: str) -> str:
    parts = value.split(".")
    if len(parts) == 1:
        table = parts[0]
    elif len(parts) == 2:
        table_database, table = parts
        if table_database != database:
            _invalid(
                "datasource.properties.native_table database must match "
                "datasource.database_name"
            )
    else:
        _invalid("datasource.properties.native_table must be table or database.table")
    if _IDENTIFIER.fullmatch(database) is None or _IDENTIFIER.fullmatch(table) is None:
        _invalid("ClickHouse database and table must be simple identifiers")
    return table


def _positive_int(value: object, field: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        _invalid(f"{field} must be a positive integer")
    return value


def _positive_number(value: object, field: str) -> float:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or float(value) <= 0
    ):
        _invalid(f"{field} must be a positive number")
    return float(value)


def _ratio(value: object, field: str) -> float:
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(float(value))
        or not 0 <= float(value) <= 1
    ):
        _invalid(f"{field} must be a finite number within [0, 1]")
    return float(value)


def _data_split_config(payload: Mapping[str, Any]) -> dict[str, Any]:
    split = _mapping(payload.get("data_split", {}), "data_split")
    train_ratio = _ratio(split.get("train_ratio", 0.7), "data_split.train_ratio")
    validation_ratio = _ratio(
        split.get("validation_ratio", 0.15),
        "data_split.validation_ratio",
    )
    test_ratio = _ratio(split.get("test_ratio", 0.15), "data_split.test_ratio")
    if not math.isclose(
        train_ratio + validation_ratio + test_ratio,
        1.0,
        rel_tol=0.0,
        abs_tol=1e-6,
    ):
        _invalid("data_split ratios must sum to 1")
    if train_ratio <= 0:
        _invalid("data_split.train_ratio must be positive")

    strategy = _text(split.get("strategy", "RANDOM"), "data_split.strategy").upper()
    if strategy not in {"RANDOM", "TIME_ORDERED"}:
        _invalid("data_split.strategy must be RANDOM or TIME_ORDERED")
    stratify = split.get("stratify", False)
    if not isinstance(stratify, bool):
        _invalid("data_split.stratify must be a boolean")
    if strategy == "TIME_ORDERED" and stratify:
        _invalid("data_split TIME_ORDERED and stratify=true are mutually exclusive")
    if stratify:
        _invalid("data_split.stratify=true is not supported by this runtime")

    random_seed = split.get("random_seed", 42)
    if random_seed is None:
        random_seed = 42
    if not isinstance(random_seed, int) or isinstance(random_seed, bool):
        _invalid("data_split.random_seed must be an integer")
    cross_validation = _mapping(
        split.get("cross_validation", {"enabled": False}),
        "data_split.cross_validation",
    )
    enabled = cross_validation.get("enabled", False)
    if not isinstance(enabled, bool):
        _invalid("data_split.cross_validation.enabled must be a boolean")
    if enabled:
        _invalid("data_split.cross_validation.enabled=true is not supported")
    return {
        "train_ratio": train_ratio,
        "validation_ratio": validation_ratio,
        "test_ratio": test_ratio,
        "seed": random_seed % (2**32),
        "split_strategy": strategy,
        "stratify": stratify,
    }


def _evaluation_config(
    payload: Mapping[str, Any], objective: str
) -> tuple[list[str], dict[str, bool]]:
    evaluation = _mapping(payload.get("evaluation", {}), "evaluation")
    objective = objective.lower()
    if objective.startswith("multi:"):
        process_metrics = ["mlogloss"]
        supported = {"auc": "auc", "accuracy": "merror", "loss": "mlogloss"}
    elif objective.startswith("binary:"):
        process_metrics = ["logloss"]
        supported = {"auc": "auc", "accuracy": "error", "loss": "logloss"}
    else:
        process_metrics = ["rmse"]
        supported = {
            "rmse": "rmse",
            "mae": "mae",
            "mape": "mape",
            "loss": "rmse",
        }

    requested: list[object] = [evaluation.get("primary_metric")]
    for field in ("additional_metrics", "realtime_metrics"):
        values = evaluation.get(field, [])
        if not isinstance(values, list):
            _invalid(f"evaluation.{field} must be an array")
        requested.extend(values)
    for raw_metric in requested:
        if raw_metric is None:
            continue
        if not isinstance(raw_metric, str) or not raw_metric.strip():
            _invalid("evaluation metric names must be non-empty strings")
        metric = supported.get(raw_metric.strip().lower())
        if metric is not None and metric not in process_metrics:
            process_metrics.append(metric)

    raw_artifacts = _mapping(evaluation.get("artifacts", {}), "evaluation.artifacts")
    artifacts: dict[str, bool] = {}
    for name, default in (
        ("roc_curve", False),
        ("threshold_analysis", False),
        ("feature_importance", True),
        ("correlation_matrix", False),
    ):
        value = raw_artifacts.get(name, default)
        if not isinstance(value, bool):
            _invalid(f"evaluation.artifacts.{name} must be a boolean")
        artifacts[name] = value
    return process_metrics, artifacts


def _relative_prefix(value: object) -> str:
    prefix = _text(value, "storage_context.prefix").strip("/")
    if not prefix or ".." in prefix.split("/"):
        _invalid("storage_context.prefix must be a safe relative path")
    return prefix


def _absolute_shared_path(value: object, field: str) -> str:
    raw = _text(value, field)
    normalized = posixpath.normpath(raw)
    if not raw.startswith("/") or normalized == "/" or ".." in raw.split("/"):
        _invalid(f"{field} must be an absolute shared path below root")
    return normalized


def _storage_config(payload: Mapping[str, Any]) -> tuple[str, str]:
    storage = _mapping(payload.get("storage_context"), "storage_context")
    storage_type = _text(storage.get("type"), "storage_context.type").lower()
    bucket = _text(storage.get("bucket"), "storage_context.bucket")
    prefix = _relative_prefix(storage.get("prefix"))
    properties = _mapping(storage.get("properties", {}), "storage_context.properties")

    if storage_type in _SHARED_STORAGE_TYPES:
        root = _absolute_shared_path(bucket, "storage_context.bucket")
        configured_ray_path = properties.get("ray_storage_path")
        ray_storage_path = (
            _absolute_shared_path(
                configured_ray_path,
                "storage_context.properties.ray_storage_path",
            )
            if configured_ray_path
            else root
        )
        return ray_storage_path, posixpath.join(root, prefix)

    if storage_type == "s3":
        if "://" in bucket or "/" in bucket.strip("/"):
            _invalid("storage_context.bucket must be an S3 bucket name")
        bundle_uri = f"s3://{bucket.strip('/')}/{prefix}"
        configured_ray_path = properties.get("ray_storage_path")
        ray_storage_path = (
            _absolute_shared_path(
                configured_ray_path,
                "storage_context.properties.ray_storage_path",
            )
            if configured_ray_path
            else f"{bundle_uri}/_ray-checkpoints"
        )
        return ray_storage_path, bundle_uri

    _invalid("storage_context.type must be nfs, nas, shared_fs, or s3")


def _column_mapping(payload: Mapping[str, Any]) -> dict[str, str]:
    columns = [*payload["features"], payload["target"]]
    entity = payload["data_query"].get("entity_key")
    if entity is not None:
        columns.append(entity)
    mapping: dict[str, str] = {}
    for column in columns:
        source, result = column["origin"]["column_name"], column["result_column"]
        if source in mapping and mapping[source] != result:
            _invalid("multiple result aliases for one source column are unsupported")
        if result in mapping.values() and mapping.get(source) != result:
            _invalid("result_column must identify one source column")
        mapping[source] = result
    return mapping


def _columns(payload: Mapping[str, Any]) -> tuple[tuple[str, ...], str]:
    return tuple(feature["result_column"] for feature in payload["features"]), payload[
        "target"
    ]["result_column"]


def _objective(
    target: Mapping[str, Any], hyper_parameters: Mapping[str, Any]
) -> tuple[str, int | None]:
    task_type = _text(target.get("task_type"), "target.task_type").upper()
    configured = hyper_parameters.get("objective")

    if task_type == "BINARY_CLASSIFICATION":
        objective = configured or "binary:logistic"
        if not isinstance(objective, str) or not objective.startswith("binary:"):
            _invalid("binary classification requires a binary XGBoost objective")
        return objective, None

    if task_type == "MULTICLASS_CLASSIFICATION":
        objective = configured or "multi:softprob"
        if not isinstance(objective, str) or not objective.startswith("multi:"):
            _invalid("multiclass classification requires a multi XGBoost objective")
        raw_num_class = hyper_parameters.get("num_class")
        if raw_num_class is None:
            label_mapping = _mapping(
                target.get("label_mapping"), "target.label_mapping"
            )
            raw_num_class = len(set(label_mapping.values()))
        num_class = _positive_int(raw_num_class, "algorithm.hyper_params.num_class")
        if num_class < 2:
            _invalid("multiclass classification requires at least two classes")
        return objective, num_class

    if task_type == "REGRESSION":
        objective = configured or "reg:squarederror"
        if not isinstance(objective, str) or not objective.startswith("reg:"):
            _invalid("regression requires a regression XGBoost objective")
        return objective, None

    _invalid("target.task_type is not supported by XGBoost training")


def _algorithm_config(
    payload: Mapping[str, Any], label_name: str, ray_storage_path: str, bundle_uri: str
) -> tuple[dict[str, Any], int]:
    algorithm = _mapping(payload.get("algorithm"), "algorithm")
    algorithm_key = _text(
        algorithm.get("algorithm_key"), "algorithm.algorithm_key"
    ).lower()
    if algorithm_key not in {"xgboost", "xgboost_reg"}:
        _invalid("only algorithm_key=xgboost is supported")

    hyper_parameters = _mapping(
        algorithm.get("hyper_params", {}), "algorithm.hyper_params"
    )
    target = _mapping(payload.get("target"), "target")
    objective, num_class = _objective(target, hyper_parameters)
    requested_rounds = _positive_int(
        hyper_parameters.get("n_estimators", hyper_parameters.get("num_rounds", 100)),
        "algorithm.hyper_params.n_estimators",
    )
    resource_limits = _mapping(payload.get("resource_limits", {}), "resource_limits")
    max_epochs = _positive_int(
        resource_limits.get("max_epochs", 1000), "resource_limits.max_epochs"
    )
    rounds = min(requested_rounds, max_epochs)
    model = {
        key: value
        for key, value in hyper_parameters.items()
        if key not in _CONTROL_HYPER_PARAMETERS
    }
    model["objective"] = objective
    if num_class is not None:
        model["num_class"] = num_class
    process_metrics, _ = _evaluation_config(payload, objective)
    model["eval_metric"] = process_metrics

    training = {
        "num_rounds": rounds,
        **_data_split_config(payload),
    }
    if resource_limits.get("max_training_time_seconds") is not None:
        training["max_training_time_seconds"] = resource_limits[
            "max_training_time_seconds"
        ]
    if str(target.get("task_type", "")).upper() == "BINARY_CLASSIFICATION":
        positive = target.get("positive_label_value")
        label_mapping = target.get("label_mapping") or {}
        positive_code: int | None
        if positive is None:
            positive_code = 1
        elif isinstance(positive, (str, int)) and not isinstance(positive, bool):
            if label_mapping:
                positive_code = label_mapping.get(str(positive))
            elif str(positive) in {"0", "1"}:
                positive_code = int(positive)
            else:
                positive_code = None
        else:
            positive_code = None
        if isinstance(positive_code, bool) or positive_code not in (0, 1):
            _invalid("target.positive_label_value must identify a binary class")
        training["positive_label"] = positive_code
    early_stopping = resource_limits.get(
        "early_stopping_patience", hyper_parameters.get("early_stopping_rounds")
    )
    if early_stopping is not None:
        training["early_stopping_rounds"] = _positive_int(
            early_stopping,
            "resource_limits.early_stopping_patience",
        )
        if training["validation_ratio"] <= 0:
            _invalid("early stopping requires a non-empty validation split")

    return (
        {
            "data": {"label_col": label_name},
            "model": model,
            "training": training,
            "ray": {"storage_path": ray_storage_path},
            "output": {"bundle_uri": bundle_uri},
        },
        rounds,
    )


def _runtime_config(payload: Mapping[str, Any]) -> tuple[int, WorkerResources]:
    # Extensions are opaque by protocol. Invalid or future content cannot reject
    # an otherwise valid request; consume only recognizable runtime hints.
    ray: Mapping[str, Any] = payload
    for key in ("extensions", "tributo", "training_runtime", "ray"):
        value = ray.get(key, {})
        ray = value if isinstance(value, Mapping) else {}
    num_workers = ray.get("num_workers", 2)
    if (
        not isinstance(num_workers, int)
        or isinstance(num_workers, bool)
        or num_workers < 2
    ):
        num_workers = 2
    cpus_per_worker = ray.get("cpus_per_worker", 1)
    if (
        isinstance(cpus_per_worker, bool)
        or not isinstance(cpus_per_worker, (int, float))
        or not math.isfinite(cpus_per_worker)
        or cpus_per_worker <= 0
    ):
        cpus_per_worker = 1
    use_gpu = ray.get("use_gpu", False)
    if not isinstance(use_gpu, bool):
        use_gpu = False
    return num_workers, WorkerResources(
        num_cpus=cpus_per_worker,
        num_gpus=1.0 if use_gpu else 0.0,
    )


def _query_scalar(value: object, clickhouse_type: str) -> str | int | float | bool:
    """Decode one typed ClickHouse query parameter without executing SQL."""
    if not isinstance(value, str):
        _invalid("data_query.query.params values must be strings")
    normalized = clickhouse_type.strip()
    while True:
        wrapper = re.fullmatch(r"(?is)(?:Nullable|LowCardinality)\((.+)\)", normalized)
        if wrapper is None:
            break
        normalized = wrapper.group(1).strip()
    lowered = normalized.lower()
    try:
        if re.fullmatch(r"u?int(?:8|16|32|64|128|256)", lowered):
            return int(value)
        if re.fullmatch(r"float(?:32|64)", lowered) or lowered.startswith("decimal"):
            parsed = float(value)
            if not math.isfinite(parsed):
                raise ValueError
            return parsed
        if lowered in {"bool", "boolean"}:
            if value.lower() in {"1", "true"}:
                return True
            if value.lower() in {"0", "false"}:
                return False
            raise ValueError
        if lowered == "string" or lowered.startswith("fixedstring"):
            return value
    except ValueError:
        _invalid("data_query contains an invalid typed class value")
    _invalid("data_query class parameter uses an unsupported ClickHouse type")


def _projection_columns(
    projection_sql: str,
    *,
    table_alias: str | None,
) -> dict[str, str]:
    identifier = r"`?[A-Za-z_][A-Za-z0-9_]*`?"
    projected_columns: dict[str, str] = {}
    for item in projection_sql.split(","):
        projection = re.fullmatch(
            rf"(?is)\s*(?:({identifier})\.)?({identifier})\s+as\s+"
            rf"({identifier})\s*",
            item,
        )
        if projection is None:
            _invalid("data_query must contain plain column projections only")
        projection_alias = projection.group(1)
        if projection_alias is not None:
            projection_alias = projection_alias.replace("`", "")
        if table_alias is not None and projection_alias not in {None, table_alias}:
            _invalid("data_query projection alias does not match its source table")
        source, result = (
            projection.group(2).replace("`", ""),
            projection.group(3).replace("`", ""),
        )
        if source in projected_columns or result in projected_columns.values():
            _invalid("data_query projection columns must be unique")
        projected_columns[source] = result
    return projected_columns


def _class_amount_sampler(
    payload: Mapping[str, Any],
    required_columns: tuple[str, ...],
    label_name: str,
) -> _RayClassAmountSampler | None:
    """Validate KnoVa's UNION ALL class sampling shape and map it to Ray Data."""
    sampling = _mapping(payload.get("data_sampling", {}), "data_sampling")
    raw_balance = sampling.get("class_balance")
    if raw_balance is None:
        return None
    balance = _mapping(raw_balance, "data_sampling.class_balance")
    strategy = _text(
        balance.get("strategy", "NONE"), "data_sampling.class_balance.strategy"
    ).upper()
    if strategy == "NONE":
        return None
    if strategy not in {"UNDERSAMPLE", "CUSTOM_AMOUNT"}:
        _invalid("data_sampling.class_balance.strategy is not supported")
    amounts = _mapping(
        balance.get("class_amounts"),
        "data_sampling.class_balance.class_amounts",
    )
    expected_amounts: dict[str, int] = {}
    for raw_value, raw_count in amounts.items():
        if not isinstance(raw_value, str) or not raw_value:
            _invalid("data_sampling.class_balance.class_amounts keys must be strings")
        expected_amounts[raw_value] = _positive_int(
            raw_count,
            "data_sampling.class_balance.class_amounts value",
        )
    if not expected_amounts:
        _invalid("data_sampling.class_balance.class_amounts must not be empty")

    data_query = _mapping(payload.get("data_query"), "data_query")
    query = _mapping(data_query.get("query"), "data_query.query")
    sql = _text(query.get("sql"), "data_query.query.sql")
    params = _mapping(query.get("params") or {}, "data_query.query.params")
    raw_branches = re.split(r"(?is)\s+union\s+all\s+", sql.strip())
    if len(raw_branches) != len(expected_amounts):
        _invalid("data_query class branches do not match class_amounts")

    tables = payload.get("tables")
    if not isinstance(tables, list) or len(tables) != 1:
        _invalid("class-balanced data_query requires exactly one physical table")
    table = _mapping(tables[0], "tables[0]")
    database = _text(table.get("database_name"), "tables[0].database_name")
    table_name = _text(table.get("table_name"), "tables[0].table_name")
    qualified_table = f"{database}.{table_name}"
    identifier = r"`?[A-Za-z_][A-Za-z0-9_]*`?"
    parameter_type = r"[A-Za-z_][A-Za-z0-9_]*(?:\([^{}]*\))?"
    branch_pattern = re.compile(
        rf"(?is)\(\s*select\s+(.+?)\s+from\s+"
        rf"({identifier}(?:\.{identifier})?)"
        rf"(?:\s+(?:as\s+)?({identifier}))?\s+where\s+"
        rf"(?:({identifier})\.)?({identifier})\s*=\s*"
        rf"\{{({identifier}):({parameter_type})\}}\s+limit\s+(\d+)\s*\)"
    )
    limits: list[tuple[object, int]] = []
    consumed_params: set[str] = set()
    consumed_amounts: set[str] = set()
    for raw_branch in raw_branches:
        match = branch_pattern.fullmatch(raw_branch.strip())
        if match is None:
            _invalid("data_query class sampling shape is not supported")
        (
            projection_sql,
            source_sql,
            raw_alias,
            raw_filter_alias,
            raw_filter_column,
            raw_parameter,
            clickhouse_type,
            raw_limit,
        ) = match.groups()
        source = source_sql.replace("`", "")
        if source not in {table_name, qualified_table}:
            _invalid("data_query class branches must use the declared physical table")
        table_alias = raw_alias.replace("`", "") if raw_alias else None
        filter_alias = raw_filter_alias.replace("`", "") if raw_filter_alias else None
        if table_alias is not None and filter_alias not in {None, table_alias}:
            _invalid("data_query class filter alias does not match its source table")
        if (
            raw_filter_column.replace("`", "")
            != payload["target"]["origin"]["column_name"]
        ):
            _invalid("data_query class branches must filter the target column")
        if _projection_columns(
            projection_sql,
            table_alias=table_alias,
        ) != _column_mapping(payload):
            _invalid(
                "data_query columns do not match the requested features and target"
            )

        parameter = raw_parameter.replace("`", "")
        if parameter in consumed_params or parameter not in params:
            _invalid("data_query class parameters are missing or duplicated")
        raw_value = params[parameter]
        if not isinstance(raw_value, str) or raw_value not in expected_amounts:
            _invalid("data_query class values do not match class_amounts")
        limit = _positive_int(int(raw_limit), "data_query class LIMIT")
        if limit != expected_amounts[raw_value]:
            _invalid("data_query class LIMIT does not match class_amounts")
        limits.append((_query_scalar(raw_value, clickhouse_type), limit))
        consumed_params.add(parameter)
        consumed_amounts.add(raw_value)

    if consumed_params != set(params) or consumed_amounts != set(expected_amounts):
        _invalid("data_query class parameters do not match class_amounts")
    return _RayClassAmountSampler(label_name=label_name, limits=tuple(limits))


def _ingestion_invocation(
    payload: Mapping[str, Any],
    feature_names: tuple[str, ...],
    label_name: str,
) -> tuple[
    IngestionInputInvocation,
    tuple[str, str],
    _RayClassAmountSampler | None,
]:
    datasource = _mapping(payload.get("datasource"), "datasource")
    datasource_type = _text(datasource.get("type"), "datasource.type").upper()
    if datasource_type != "CLICKHOUSE":
        _invalid("only datasource.type=CLICKHOUSE is supported")
    properties = _mapping(datasource.get("properties", {}), "datasource.properties")
    column_mapping = _column_mapping(payload)
    source_columns = tuple(column_mapping)
    sampler = _class_amount_sampler(payload, source_columns, label_name)
    native_table, transforms = _native_clickhouse_read(
        payload,
        properties,
        source_columns,
        class_query_validated=sampler is not None,
    )
    host = _text(datasource.get("host"), "datasource.host")
    database = _text(datasource.get("database_name"), "datasource.database_name")
    table_name = _native_table_name(native_table, database)
    port = _positive_int(datasource.get("port", 8123), "datasource.port")
    if port > 65535:
        _invalid("datasource.port must be no greater than 65535")
    if any(character in host for character in "/@?#"):
        _invalid("datasource.host is invalid")
    uri_host = host if ":" not in host or host.startswith("[") else f"[{host}]"

    columns = list(source_columns)
    for step in transforms.steps:
        if (
            isinstance(step, (FilterEq, FilterNotEq, FilterComparison))
            and step.column not in columns
        ):
            columns.append(step.column)
    options: dict[str, Any] = {
        "table": table_name,
        "host": host,
        "port": port,
        "database": database,
        "columns": columns,
        # KnoVa supplies a ClickHouse Distributed coordinator table. Let
        # ClickHouse fan the read out to its shards, then let Ray repartition
        # the resulting dataset for the training workers. Partition discovery
        # is only valid for direct physical tables.
        "partitioning": {"mode": "single"},
    }
    username = datasource.get("username")
    password = datasource.get("password")
    if username is not None:
        options["user"] = _text(username, "datasource.username")
    reference = datasource.get("credential_ref")
    if reference is not None or password is None:
        if isinstance(reference, str) and reference.startswith("env://"):
            password_env = reference.removeprefix("env://")
            if _ENV_NAME.fullmatch(password_env) is None:
                _invalid("datasource.credential_ref must name an environment variable")
            password = os.environ.get(password_env, "")
        elif reference is not None:
            _invalid("datasource.credential_ref must use env://VARIABLE")
        else:
            password = os.environ.get("TRIBUTO_CLICKHOUSE_PASSWORD", "")
    if not isinstance(password, str):
        _invalid("datasource.password must be a string or env credential reference")

    renames = tuple(
        ColumnRename(source=source, target=result)
        for source, result in column_mapping.items()
        if source != result
    )
    if renames:
        transforms = TransformPipeline(
            steps=(*transforms.steps, RenameColumns(renames=renames))
        )

    source = ProviderSourceConfig(
        provider="tributo.clickhouse",
        uri=f"clickhouse://{uri_host}:{port}/{database}",
        options=options,
    )
    return (
        IngestionInputInvocation(
            request=IngestionRequest(
                source=source,
                engine="ray",
                transforms=transforms,
            )
        ),
        (str(username or ""), password),
        sampler,
    )


@contextmanager
def _clickhouse_environment(credentials: tuple[str, str]) -> Iterator[None]:
    names = {
        "TRIBUTO_CLICKHOUSE_USER": credentials[0],
        "TRIBUTO_CLICKHOUSE_PASSWORD": credentials[1],
    }
    previous = {name: os.environ.get(name) for name in names}
    try:
        os.environ.update(names)
        yield
    finally:
        for name, value in previous.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value


def _native_clickhouse_read(
    payload: Mapping[str, Any],
    properties: Mapping[str, Any],
    required_columns: tuple[str, ...],
    *,
    class_query_validated: bool = False,
) -> tuple[str, TransformPipeline]:
    """Map a restricted single-table query to typed ingestion transforms."""
    configured = properties.get("native_table")
    tables = payload.get("tables")
    data_query = payload.get("data_query")
    identifier = r"`?[A-Za-z_][A-Za-z0-9_]*`?"
    if (
        not isinstance(tables, list)
        or len(tables) != 1
        or not isinstance(data_query, Mapping)
    ):
        _invalid(
            "datasource.properties.native_table is required unless data_query "
            "is a simple single-table projection"
        )

    table = _mapping(tables[0], "tables[0]")
    database = _text(table.get("database_name"), "tables[0].database_name")
    table_name = _text(table.get("table_name"), "tables[0].table_name")
    query = _mapping(data_query.get("query"), "data_query.query")
    sql = _text(query.get("sql"), "data_query.query.sql")
    params = _mapping(query.get("params") or {}, "data_query.query.params")
    qualified = f"{database}.{table_name}"
    if (
        configured is not None
        and _native_table_name(
            _text(configured, "datasource.properties.native_table"), database
        )
        != table_name
    ):
        _invalid(
            "datasource.properties.native_table must match data_query source table"
        )
    if class_query_validated:
        return qualified, TransformPipeline()

    match = re.fullmatch(
        rf"(?is)\s*select\s+(.+?)\s+from\s+"
        rf"({identifier}(?:\.{identifier})?)"
        rf"(?:\s+(?:as\s+)?((?!(?:WHERE|LIMIT)\b){identifier}))?"
        rf"(?:\s+where\s+(.+?))?(?:\s+limit\s+(\d+))?\s*;?\s*",
        sql,
    )
    source_name = match.group(2).replace("`", "") if match else None
    if source_name not in {table_name, qualified}:
        _invalid(
            "datasource.properties.native_table is required unless data_query "
            "is a simple single-table projection"
        )

    assert match is not None
    table_alias = match.group(3)
    if table_alias is not None:
        table_alias = table_alias.replace("`", "")
    declared_alias = table.get("table_alias")
    if (
        table_alias is not None
        and declared_alias is not None
        and table_alias != declared_alias
    ):
        _invalid("data_query alias does not match its source table")
    if _projection_columns(match.group(1), table_alias=table_alias) != _column_mapping(
        payload
    ):
        _invalid("data_query columns do not match the requested features and target")

    steps: list[FilterEq | FilterNotEq | FilterComparison | Limit | SelectColumns] = []
    consumed_params: set[str] = set()
    if match.group(4) is not None:
        for condition in re.split(r"\s+AND\s+", match.group(4), flags=re.IGNORECASE):
            predicate = re.fullmatch(
                rf"\s*(\(*)\s*(?:({identifier})\.)?({identifier})"
                rf"\s*(<=|>=|!=|<>|=|<|>)\s*"
                rf"\{{([A-Za-z_][A-Za-z0-9_]*):([A-Za-z0-9_(), ]+)\}}"
                rf"\s*(\)*)\s*",
                condition,
            )
            if predicate is None or len(predicate.group(1)) != len(predicate.group(7)):
                _invalid(
                    "data_query WHERE supports only AND-combined "
                    "parameterized scalar filters"
                )
            filter_alias = predicate.group(2)
            if (
                filter_alias is not None
                and filter_alias.replace("`", "") != table_alias
            ):
                _invalid("data_query filter alias does not match its source table")
            column, operator, parameter, parameter_type = predicate.group(3, 4, 5, 6)
            if parameter not in params:
                _invalid("data_query WHERE references a missing parameter")
            value = _query_scalar(params[parameter], parameter_type)
            column = column.replace("`", "")
            if operator == "=":
                steps.append(FilterEq(column=column, value=value))
            elif operator in {"!=", "<>"}:
                steps.append(FilterNotEq(column=column, value=value))
            else:
                steps.append(
                    FilterComparison(
                        column=column,
                        operator=cast(
                            Literal["lt", "lte", "gt", "gte"],
                            {"<": "lt", "<=": "lte", ">": "gt", ">=": "gte"}[operator],
                        ),
                        value=value,
                    )
                )
            consumed_params.add(parameter)
    if consumed_params != set(params):
        _invalid("data_query contains unused parameters")
    if match.group(5) is not None:
        steps.append(Limit(count=int(match.group(5))))
    if steps:
        # Filter-only columns must be available to Ray, but must not become
        # accidental model features. Preserve filter -> limit -> projection order.
        steps.append(SelectColumns(columns=required_columns))
    return qualified, TransformPipeline(steps=tuple(steps))


def _build_execution(
    request: TrainingExecutionRequest,
) -> tuple[
    ExecutionRequest,
    InputExecutionContext,
    InputResolutionContext,
    int,
    tuple[str, str],
    Callable[[Any], Any] | None,
]:
    logger.info("Building training execution plan: operation_id=%s", request.job_id)
    payload = request.model_dump(mode="python")
    try:
        validate_training_payload(payload)
    except ProtocolValidationError as exc:
        raise _TrainingConfigurationError(str(exc)) from None
    query = _mapping(payload.get("data_query") or {}, "data_query")
    if query.get("mode", "DIRECT_QUERY") != "DIRECT_QUERY":
        _invalid("only data_query.mode=DIRECT_QUERY is supported by this runtime")
    _validate_feature_treatments(payload)
    feature_names, label_name = _columns(payload)
    ray_storage_path, bundle_uri = _storage_config(payload)
    algorithm_config, rounds = _algorithm_config(
        payload, label_name, ray_storage_path, bundle_uri
    )
    worker_count, resources = _runtime_config(payload)
    invocation, credentials, sampler = _ingestion_invocation(
        payload, feature_names, label_name
    )
    transform = _target_encoder(
        _mapping(payload.get("target"), "target"),
        label_name,
        algorithm_config["model"],
        sampler,
    )
    transform = _RayInputValidation(payload, transform)
    sampling = _mapping(payload.get("data_sampling", {}), "data_sampling")
    logger.info(
        "Training execution plan ready: operation_id=%s features=%d label=%s "
        "workers=%d rounds=%d sample_limit=%s",
        request.job_id,
        len(feature_names),
        label_name,
        worker_count,
        rounds,
        sampling.get("sample_limit", "<unspecified>"),
    )
    values = {_INPUT_REFERENCE: invocation}
    execution = ExecutionRequest(
        algorithm_request=AlgorithmRequest(
            algorithm="xgboost",
            operation=AlgorithmOperation.FIT,
            input_binding=InputBinding(
                name="train",
                resolver_id=INGESTION_RESOLVER_ID,
                reference=_INPUT_REFERENCE,
                feature_names=feature_names,
                label_name=label_name,
            ),
            algorithm_config=algorithm_config,
        ),
        profile=ExecutionProfile.CLUSTER,
        worker_count=worker_count,
        resources_per_worker=resources,
    )
    return (
        execution,
        InputExecutionContext(values=values),
        InputResolutionContext(values=values),
        rounds,
        credentials,
        transform,
    )


def _validate_feature_treatments(payload: Mapping[str, Any]) -> None:
    """Reject requested preprocessing that this passthrough runtime cannot apply."""
    defaults = _mapping(payload.get("feature_engineering") or {}, "feature_engineering")
    allowed = {
        "missing_value_strategy": {"AUTO"},
        "outlier_strategy": {"AUTO", "NONE"},
        "scaling_method": {"AUTO", "NONE"},
        "encoding_method": {"AUTO", "NONE"},
    }
    for feature in payload.get("features", []):
        treatment = _mapping(feature.get("treatment") or {}, "features.treatment")
        if treatment.get("treatment_type") not in (None, "AUTO", "NUMERIC"):
            _invalid(
                "features.treatment.treatment_type is not supported by this runtime"
            )
        for field, supported in allowed.items():
            value = treatment.get(field)
            if value is None:
                value = defaults.get("default_" + field)
            if value is not None and (
                not isinstance(value, str) or value not in supported
            ):
                _invalid(f"features.treatment.{field} is not supported by this runtime")


def _safe_storage_properties(value: object) -> dict[str, str]:
    """Keep protocol storage hints while excluding credentials and Ray-only paths."""
    properties = _mapping(value, "storage_context.properties")
    safe: dict[str, str] = {}
    for raw_name, raw_value in properties.items():
        if not isinstance(raw_name, str) or not isinstance(raw_value, str):
            continue
        name = raw_name.lower()
        if name == "ray_storage_path" or any(
            token in name for token in _SENSITIVE_PROPERTY_TOKENS
        ):
            continue
        safe[raw_name] = raw_value
    return safe


def _artifact_storage(
    request: TrainingExecutionRequest,
    canonical_uri: str,
) -> dict[str, Any]:
    payload = request.model_dump(mode="python")
    requested = _mapping(payload.get("storage_context"), "storage_context")
    requested_type = _text(requested.get("type"), "storage_context.type").lower()
    requested_bucket = _text(requested.get("bucket"), "storage_context.bucket")
    requested_prefix = _relative_prefix(requested.get("prefix"))
    properties = _safe_storage_properties(requested.get("properties", {}))

    if requested_type == "s3":
        parsed = urlsplit(canonical_uri)
        if parsed.scheme != "s3" or parsed.netloc != requested_bucket:
            raise _TrainingExecutionError(
                "published Bundle is outside the requested S3 storage"
            )
        prefix = posixpath.normpath(parsed.path.strip("/"))
        try:
            contained = posixpath.commonpath([requested_prefix, prefix])
        except ValueError as exc:
            raise _TrainingExecutionError(
                "published Bundle is outside the requested S3 storage"
            ) from exc
        if contained != requested_prefix or prefix == requested_prefix:
            raise _TrainingExecutionError(
                "published Bundle is outside the requested S3 storage"
            )
        return {
            "type": "s3",
            "bucket": requested_bucket,
            "prefix": f"{prefix}/",
            "properties": properties,
        }

    if requested_type in _SHARED_STORAGE_TYPES:
        root = posixpath.normpath(requested_bucket)
        requested_root = posixpath.join(root, requested_prefix)
        bundle_path = posixpath.normpath(canonical_uri)
        try:
            contained = posixpath.commonpath([requested_root, bundle_path])
        except ValueError as exc:
            raise _TrainingExecutionError(
                "published Bundle is outside the requested shared storage"
            ) from exc
        if contained != requested_root or bundle_path == requested_root:
            raise _TrainingExecutionError(
                "published Bundle is outside the requested shared storage"
            )
        return {
            "type": "nas",
            "bucket": root,
            "prefix": f"{posixpath.relpath(bundle_path, root).strip('/')}/",
            "properties": properties,
        }

    raise _TrainingExecutionError("published Bundle storage type is unsupported")


def _signature_names(signature: object, field: str) -> list[str]:
    if not isinstance(signature, Mapping):
        return []
    fields = signature.get(field.replace("_names", "_fields"), [])
    if isinstance(fields, list):
        names = [item.get("name") for item in fields if isinstance(item, Mapping)]
        if names and all(isinstance(name, str) and name for name in names):
            return [str(name) for name in names]
    names = signature.get(field, [])
    if isinstance(names, list) and all(isinstance(name, str) for name in names):
        return list(names)
    return []


def _artifact_manifest(
    request: TrainingExecutionRequest,
    outputs: Mapping[str, Any],
) -> dict[str, Any]:
    bundle_id = _text(outputs.get("bundle_id"), "training output bundle_id")
    bundle_uri = _text(outputs.get("bundle_uri"), "training output bundle_uri")
    manifest_sha256 = _text(
        outputs.get("manifest_sha256"), "training output manifest_sha256"
    )
    try:
        bundle = load_bundle(
            BundleRef(
                canonical_uri=bundle_uri,
                bundle_id=bundle_id,
                manifest_sha256=manifest_sha256,
            )
        )
    except Exception:
        raise _TrainingExecutionError(
            "published Bundle manifest validation failed"
        ) from None

    loaded_bundle_id = _text(bundle.get("bundle_id"), "Bundle bundle_id")
    if loaded_bundle_id != bundle_id:
        raise _TrainingExecutionError("published Bundle identity validation failed")
    canonical_uri = _text(bundle.get("canonical_uri"), "Bundle canonical_uri")
    artifacts = bundle.get("artifacts")
    if not isinstance(artifacts, list):
        raise _TrainingExecutionError("published Bundle artifacts are invalid")

    input_names = _signature_names(bundle.get("input_signature"), "input_names")
    output_names = _signature_names(bundle.get("output_signature"), "output_names")
    alternatives: list[dict[str, Any]] = []
    total_size = 0
    seen_formats: set[str] = set()
    for raw_artifact in artifacts:
        if not isinstance(raw_artifact, Mapping):
            continue
        bundle_format = raw_artifact.get("format")
        if bundle_format not in {"onnx", "ubj"}:
            continue
        protocol_format = "xgboost" if bundle_format == "ubj" else "onnx"
        if protocol_format in seen_formats:
            raise _TrainingExecutionError(
                "published Bundle has duplicate model artifact formats"
            )
        artifact_name = _text(raw_artifact.get("name"), "Bundle artifact name")
        raw_files = raw_artifact.get("files")
        if not isinstance(raw_files, list) or not raw_files:
            raise _TrainingExecutionError("published Bundle artifact files are invalid")
        files: list[dict[str, Any]] = []
        for raw_file in raw_files:
            if not isinstance(raw_file, Mapping):
                raise _TrainingExecutionError(
                    "published Bundle artifact file is invalid"
                )
            relative_path = _text(
                raw_file.get("relative_path"), "Bundle artifact relative_path"
            )
            sha256 = _text(raw_file.get("sha256"), "Bundle artifact sha256")
            size = raw_file.get("size_bytes")
            if not isinstance(size, int) or isinstance(size, bool) or size < 0:
                raise _TrainingExecutionError(
                    "published Bundle artifact size is invalid"
                )
            metadata: dict[str, Any] = {}
            if protocol_format == "onnx":
                metadata = {
                    "input_names": input_names,
                    "output_names": output_names,
                }
            elif protocol_format == "xgboost":
                metadata = {"supports_tree_shap": True}
            files.append(
                {
                    "path": posixpath.join("artifacts", artifact_name, relative_path),
                    "size": size,
                    "hash": f"sha256:{sha256}",
                    "metadata": metadata,
                }
            )
            total_size += size
        alternatives.append({"format": protocol_format, "files": files})
        seen_formats.add(protocol_format)

    if "onnx" not in seen_formats or "xgboost" not in seen_formats:
        raise _TrainingExecutionError(
            "published Bundle must contain ONNX and XGBoost artifacts"
        )

    algorithm = _mapping(request.algorithm, "algorithm")
    return {
        "model_id": request.model_id,
        "version_id": request.version_id,
        "tenant_id": request.tenant_id,
        "created_at": bundle.get("created_at"),
        "algorithm_key": _text(
            algorithm.get("algorithm_key"), "algorithm.algorithm_key"
        ).lower(),
        "storage": _artifact_storage(request, canonical_uri),
        "model_artifacts": {
            "model_weights": {
                "comment": "Tributo XGBoost model Bundle",
                "required_for_inference": True,
                "alternatives": alternatives,
            }
        },
        "total_size_bytes": total_size,
    }


def _internal_metrics(result: AlgorithmRunResult) -> Mapping[str, Any]:
    metrics = getattr(result.execution, "metrics", {})
    if not isinstance(metrics, Mapping):
        raise _TrainingExecutionError("training metrics are invalid")
    return metrics


def _sample_rows(result: AlgorithmRunResult) -> dict[str, int]:
    raw_rows = _internal_metrics(result).get("sample_rows")
    if not isinstance(raw_rows, Mapping):
        raise _TrainingExecutionError("training split row counts are missing")
    rows: dict[str, int] = {}
    for name in ("total", "train", "validation", "test"):
        value = raw_rows.get(name)
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            raise _TrainingExecutionError("training split row counts are invalid")
        rows[name] = value
    if rows["train"] + rows["validation"] + rows["test"] != rows["total"]:
        raise _TrainingExecutionError("training split row counts are inconsistent")
    return rows


def _evaluation_metrics(result: AlgorithmRunResult) -> list[dict[str, Any]]:
    metrics: list[dict[str, Any]] = []
    raw_metrics = _internal_metrics(result).get("evaluation", {})
    if not isinstance(raw_metrics, Mapping):
        return metrics
    for name, value in raw_metrics.items():
        if (
            isinstance(name, str)
            and isinstance(value, (int, float))
            and not isinstance(value, bool)
            and math.isfinite(float(value))
        ):
            metrics.append({"metric_name": name.lower(), "value": float(value)})
    return sorted(metrics, key=lambda item: item["metric_name"])


def _evaluation_details(
    result: AlgorithmRunResult,
    task_type: str,
    target: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    raw_details = _internal_metrics(result).get("evaluation_details", {})
    if not isinstance(raw_details, Mapping):
        raw_details = {}
    details = dict(raw_details)
    confusion = details.get("confusion_matrix")
    label_mapping = (target or {}).get("label_mapping")
    if isinstance(confusion, Mapping) and isinstance(label_mapping, Mapping):
        labels = confusion.get("labels")
        if isinstance(labels, (list, tuple)):
            inverse = {str(code): label for label, code in label_mapping.items()}
            details["confusion_matrix"] = {
                **confusion,
                "labels": [inverse.get(str(label), str(label)) for label in labels],
            }
    if task_type in {"BINARY_CLASSIFICATION", "MULTICLASS_CLASSIFICATION"}:
        details.setdefault("confusion_matrix", None)
        details.setdefault("roc_curve", None)
        details.setdefault("threshold_analysis", None)
    return details


def _feature_analysis(
    payload: Mapping[str, Any],
    result: AlgorithmRunResult,
    feature_ids: Mapping[str, str],
) -> dict[str, Any] | None:
    evaluation = _mapping(payload.get("evaluation", {}), "evaluation")
    artifacts = _mapping(evaluation.get("artifacts", {}), "evaluation.artifacts")
    include_importance = artifacts.get("feature_importance", True) is True
    include_correlation = artifacts.get("correlation_matrix", False) is True
    if not include_importance and not include_correlation:
        return None

    importance: list[dict[str, Any]] = []
    raw_importance = _internal_metrics(result).get("feature_importance", [])
    # Tributo freezes portable result lists to tuples at its public result
    # boundary.  Accept both shapes so feature importance survives that
    # boundary and reaches KnoVa's terminal event.
    if include_importance and isinstance(raw_importance, (list, tuple)):
        for item in raw_importance:
            if not isinstance(item, Mapping):
                continue
            name = item.get("model_feature_name")
            rank = item.get("rank")
            score = item.get("importance_score")
            if (
                isinstance(name, str)
                and name in feature_ids
                and isinstance(rank, int)
                and not isinstance(rank, bool)
                and isinstance(score, (int, float))
                and not isinstance(score, bool)
                and math.isfinite(float(score))
            ):
                importance.append(
                    {
                        "rank": rank,
                        "feature_id": feature_ids[name],
                        "model_feature_name": name,
                        "importance_score": float(score),
                    }
                )
    return {
        "importance_ranking": importance,
        "correlation_matrix": (
            _internal_metrics(result).get("correlation_matrix")
            if include_correlation
            else None
        ),
    }


def _completed_payload(
    request: TrainingExecutionRequest,
    result: AlgorithmRunResult,
) -> dict[str, Any]:
    payload = request.model_dump(mode="python")
    features = payload.get("features")
    if not isinstance(features, list) or not features:
        raise _TrainingExecutionError("training features are required")
    target = _mapping(payload.get("target"), "target")
    task_type = _text(target.get("task_type"), "target.task_type").upper()
    rows = _sample_rows(result)
    metrics = _evaluation_metrics(result)
    requested_evaluation = payload.get("evaluation")
    primary_name = None
    if isinstance(requested_evaluation, Mapping):
        raw_primary = requested_evaluation.get("primary_metric")
        if isinstance(raw_primary, str):
            primary_name = raw_primary.lower()
    primary_metric = next(
        (metric for metric in metrics if metric["metric_name"] == primary_name),
        None,
    )
    primary = (
        {
            "name": primary_metric["metric_name"],
            "value": primary_metric["value"],
        }
        if primary_metric is not None
        else None
    )

    model_features: list[dict[str, Any]] = []
    feature_ids: dict[str, str] = {}
    for index, raw_feature in enumerate(features):
        feature = _mapping(raw_feature, f"features[{index}]")
        model_feature_name = _text(
            feature.get("result_column"), f"features[{index}].result_column"
        )
        feature_id = str(feature.get("feature_id") or f"f{index + 1:03d}")
        feature_ids[model_feature_name] = feature_id
        model_features.append(
            {
                "model_feature_index": index,
                "model_feature_name": model_feature_name,
                "feature_id": feature_id,
                "transformation": "PASSTHROUGH",
            }
        )

    algorithm = _mapping(request.algorithm, "algorithm")
    return {
        "result_summary": {
            "primary_metric": primary,
            "sample_rows": rows,
        },
        "training_result": {
            "algorithm_key": _text(
                algorithm.get("algorithm_key"), "algorithm.algorithm_key"
            ).lower(),
            "task_type": task_type,
            "model_features": model_features,
            "evaluation": {
                "eval_type": task_type,
                "sample_rows": rows["test"],
                "metrics": metrics,
                "details": _evaluation_details(
                    result, task_type, payload.get("target")
                ),
            },
            "feature_analysis": _feature_analysis(
                payload,
                result,
                feature_ids,
            ),
            "tuning_result": None,
        },
        "artifact_manifest": _artifact_manifest(
            request, dict(result.execution.outputs)
        ),
    }


def execute_training(
    request: TrainingExecutionRequest,
    reporter: Any,
) -> AlgorithmRunResult:
    """Execute one KnoVa request through public Tributo algorithm contracts."""
    try:
        (
            execution,
            input_context,
            _resolution_context,
            _rounds,
            clickhouse_credentials,
            ray_dataset_transform,
        ) = _build_execution(request)
    except _TrainingConfigurationError as exc:
        _log_training_failure(
            "Training request mapping failed",
            request.job_id,
            exc,
        )
        raise exc from None
    except Exception as exc:
        _log_training_failure(
            "Unexpected training plan failure",
            request.job_id,
            exc,
        )
        raise _TrainingConfigurationError("training request mapping failed") from None

    binding = execution.algorithm_request.input_binding
    if not isinstance(binding, InputBinding):
        raise _TrainingExecutionError("training requires one tabular input binding")
    publishing = False
    try:
        logger.info(
            "Training execution preparing: operation_id=%s features=%d workers=%d",
            request.job_id,
            len(binding.feature_names),
            execution.worker_count,
        )
        if callable(getattr(reporter, "configure_timeout", None)):
            reporter.configure_timeout(
                execution.algorithm_request.algorithm_config["training"].get(
                    "max_training_time_seconds"
                )
            )
        if callable(getattr(reporter, "check_control", None)):
            reporter.check_control()
        reporter.phase("PREPARING")
        if isinstance(ray_dataset_transform, _RayInputValidation):
            ray_dataset_transform.reporter = reporter
        if getattr(request, "tuning", {}).get("mode") == "AUTO":
            reporter.publish(
                "LOG",
                {
                    "level": "warning",
                    "message": (
                        "AUTO tuning is not implemented; running one MANUAL "
                        "training with baseline hyperparameters"
                    ),
                },
                phase="LOADING_DATA",
            )
        invocation = input_context.values.get(_INPUT_REFERENCE)
        if not isinstance(invocation, IngestionInputInvocation):
            raise _TrainingExecutionError("training input invocation is invalid")
        payload = request.model_dump(mode="python")
        target = _mapping(payload.get("target"), "target")
        task_type = _text(target.get("task_type"), "target.task_type").upper()
        model_config = execution.algorithm_request.algorithm_config.get("model", {})
        if not isinstance(model_config, Mapping):
            raise _TrainingExecutionError("training model configuration is invalid")
        raw_num_class = model_config.get("num_class")
        _, evaluation_artifacts = _evaluation_config(
            payload,
            _text(model_config.get("objective"), "algorithm objective"),
        )
        with _clickhouse_environment(clickhouse_credentials):
            logger.info(
                "Starting distributed XGBoost training: operation_id=%s "
                "features=%d workers=%d task_type=%s",
                request.job_id,
                len(binding.feature_names),
                execution.worker_count,
                task_type,
            )
            result = run_xgboost_training(
                ingestion_request=invocation.request,
                feature_names=binding.feature_names,
                label_name=_text(binding.label_name, "training label name"),
                algorithm_config=execution.algorithm_request.algorithm_config,
                worker_count=execution.worker_count,
                resources=execution.resources_per_worker or WorkerResources(),
                run_id=request.job_id,
                reporter=reporter,
                task_type=task_type,
                num_class=(int(raw_num_class) if raw_num_class is not None else None),
                evaluation_artifacts=evaluation_artifacts,
                ray_dataset_transform=ray_dataset_transform,
            )
        logger.info(
            "Distributed XGBoost training returned: operation_id=%s status=%s",
            request.job_id,
            result.execution.status,
        )
        if result.execution.status != "succeeded":
            raise _TrainingExecutionError("XGBoost training did not succeed")
        publishing = True
        reporter.publish(
            "COMPLETED",
            _completed_payload(request, result),
            phase="COMPLETED",
        )
        return result
    except _TrainingExecutionError as exc:
        if type(exc) is _TrainingExecutionError:
            exc.code, exc.phase = _classify_training_failure(
                exc, reporter, publishing=publishing
            )
        _log_training_failure(
            "Training execution failed",
            request.job_id,
            exc,
        )
        raise exc from None
    except Exception as exc:
        if getattr(exc, "code", None) in {
            "EXECUTION_TIMEOUT",
            "TRAINING_TIMEOUT",
            "CANCELLED",
        }:
            raise
        _log_training_failure(
            "Unexpected XGBoost training failure",
            request.job_id,
            exc,
        )
        if (
            type(exc) is ValueError
            and len(exc.args) == 1
            and type(exc.args[0]) is str
            and exc.args[0] in _KNOWN_DATA_FAILURES
        ):
            code = (
                "EMPTY_DATASET"
                if exc.args[0] == "training dataset is empty"
                else "DATA_QUERY_FAILED"
            )
            raise _execution_error(
                _KNOWN_DATA_FAILURES[exc.args[0]], code, "LOADING_DATA"
            ) from None
        code, phase = _classify_training_failure(exc, reporter, publishing=publishing)
        raise _execution_error(
            f"XGBoost training execution failed ({type(exc).__name__})", code, phase
        ) from None


__all__ = ["execute_training"]
